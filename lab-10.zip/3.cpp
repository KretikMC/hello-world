#include <iostream>
#include <cmath>
using namespace std;


int main()
{
    setlocale(LC_ALL, "Rus");
	int a;
	cout << "Ваше число = ";
	cin >> a;
	if (a < 1)
	{
	    cout << "Что-то не так!";
	    return 0;
	}
	if ((a > 9) and (a < 100) and (a % 2 == 0))
	{
	    cout << "Ваше число - четное двухзначное!";
	    return 0;
	}
	else
	{
	    cout << "Что-то не так!";
	    return 0;
	}
}