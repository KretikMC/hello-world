#include <iostream>
#include <cmath>
using namespace std;


int main()
{
    setlocale(LC_ALL, "Rus");
	int a, b, c, d;
	cout << "Ваше число = ";
	cin >> a;
	b = a % 100;
	c = (a - (c * 100)) / 10;
	d = a - (c * 100) - (b * 10);
	if ((a < 100) or (a > 999))
	{
	    cout << "Что-то не так!";
	    return 0;
	}
	if (((b < c) and (c < d)) or ((b > c) and (c > d)))
	{
	    cout << "Ваше число образует последовательность!";
	    return 0;
	}
	else
	{
	    cout << "Что-то не так!";
	    return 0;
	}
}