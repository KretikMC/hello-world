#include <iostream>
#include <cmath>
using namespace std;


int main()
{
	setlocale(LC_ALL, "Rus");
	int a, b, c;
	cout << "a = ";
	cin >> a;
	cout << "b = ";
	cin >> b;
	cout << "c = ";
	cin >> c;
	if ((a < b) and (b < c))
	{
	    cout << "Все верно!";
	    return 0;
	}
	else
	{
	    cout << "Что-то не так!";
	    return 0;
	}
}