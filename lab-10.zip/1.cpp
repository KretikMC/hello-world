#include <iostream>
#include <cmath>
using namespace std;


int main()
{
	setlocale(LC_ALL, "Rus");
	int a, b;
	cout << "a = ";
	cin >> a;
	cout << "b = ";
	cin >> b;
	if ((a > 2) and (b <= 3))
	{
	    cout << "Все верно!";
	    return 0;
	}
	else
	{
	    cout << "Что-то не так!";
	    return 0;
	}
}