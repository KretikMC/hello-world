#include <iostream>
#include <cmath>
using namespace std;


int main()
{
	setlocale(LC_ALL, "Rus");
	int k, n;
	cout << "Секунд с начала дня = ";
	cin >> k;
	if (k < 1)
	{
		cout << "Так нельзя!!!";
		return 0;
	}
	n = k % 60;
	cout << "Секунд с начала минуты = " << n;
}
